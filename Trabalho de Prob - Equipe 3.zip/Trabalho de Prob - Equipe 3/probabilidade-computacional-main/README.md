# probabilidade-computacional
Trabalho colaborativo desenvolvido na disciplina de Probabilidade e Estatística
